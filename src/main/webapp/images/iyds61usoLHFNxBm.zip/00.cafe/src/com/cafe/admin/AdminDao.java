package com.cafe.admin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;




public class AdminDao {
	private File adminFile;

	public AdminDao() throws Exception {
		init();
	}

	private void init() throws Exception {
		adminFile = new File("admin.ser");
		if (!adminFile.exists()) {
			System.out.println("------���ϻ���[admin.ser]-----");
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(adminFile));
			oos.writeObject(new ArrayList<AdminVo>());

		} else {
			//System.out.println("------��������[member_list.ser]-----");
		}
	}

	/*
	 * file --> ArrayList<admin>
	 */
	private ArrayList<AdminVo> readFile() throws Exception {
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(adminFile));
		ArrayList<AdminVo> adminList = (ArrayList<AdminVo>) ois.readObject();
		ois.close();
		return adminList;
	}

	/*
	 * ArrayList<adminList>--> file
	 */
	private void writeFile(ArrayList<AdminVo> adminList) throws Exception {
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(adminFile));
		oos.writeObject(adminList);
		oos.close();

	}
	/*
	 * Create
	 */
	public void create(AdminVo admin) throws Exception {
		ArrayList<AdminVo> adminList = readFile();
		adminList.add(admin);
		writeFile(adminList);
	}
	/*
	 * Read
	 */
	public ArrayList<AdminVo> readAll() throws Exception {
		return readFile();
	}

	/*
	 * Read
	 */
	public AdminVo readOne(String adminName) throws Exception {
		AdminVo findMember = null;
		ArrayList<AdminVo> adminList = readFile();
		for (AdminVo member : adminList) {
			if (member.getEmName().equals(adminName)) {
				findMember = member;
				break;
			}
		}
		return findMember;
	}
	/*
	 *Update
	 */
	public void update(AdminVo updateMember) throws Exception {
		ArrayList<AdminVo> adminList = this.readFile();

		for (int i = 0; i < adminList.size(); i++) {
			AdminVo tempMember = adminList.get(i);
			if (tempMember.getEmName().equals(updateMember.getEmName())) {
				adminList.set(i, updateMember);
				break;
			}
		}

		this.writeFile(adminList);

	}
	/*
	 *Delete
	 */
	public void delete(int no) throws Exception{
		ArrayList<AdminVo> adminList = this.readFile();
		for (int i = 0; i < adminList.size(); i++) {
			AdminVo tempMember = adminList.get(i);
			if (tempMember.getEmNo() == no) {
				adminList.remove(i);
				break;
			}
		}
		this.writeFile(adminList);
	}
	
}
