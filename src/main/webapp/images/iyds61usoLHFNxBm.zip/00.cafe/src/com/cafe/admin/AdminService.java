package com.cafe.admin;

import java.util.ArrayList;

import com.cafe.member.MemberDao;
import com.cafe.member.MemberVo;

public class AdminService {
	private AdminDao adminDao;	//������ ���ٽ� ����ϴ� Dao ��ü

	public AdminService() throws Exception{
		adminDao = new AdminDao();
	}
	/*
	 * 	�����ڻ���
	 */
	public boolean joinAdmin() throws Exception{
		
//		System.out.println("[2] MemberService.joinMember");
//		ArrayList<MemberVO> memberList = memberDao.selectAll();
//		for (MemberVO memberVO : memberList) {
//			if(memberVO.getId().equals(m.getId())){
//				return false;
//			}
//		}
//		m.setNo(returnLastNo()+1);
//		memberDao.insert(m);
		return true;
	}
	/*
	 * 	2. �α���
	 */
	public boolean login(String id, String pw) throws Exception{
		
//		MemberVO memberVO=memberDao.selectById(id);
//		if(memberVO==null){
//			return false;
//		}else{
//			if(memberVO.matchPassword(pw)){
//				FirstPageService.setActiveMember(memberVO);
//				return true;
//			}else{
//				return false;
//			}
//		}
		return false;
	}
	/*
	 * 	3. ������ ����
	 */
	public boolean deleteAdmin() throws Exception{
//		System.out.println(FirstPageService.getActiveMember());
//		memberDao.deleteById(FirstPageService.getActiveMember().getId());
		return true;
	}
	
	/*
	 * 	4. ������ ���� ����
	 */
	public boolean modifyAdmin() throws Exception{
//		m.setNo(FirstPageService.activeMember.getNo());
//		memberDao.update(m);
		return true;
	}
	
	/*
	 * 	5. ȸ�� �˻�(�� �ʵ庰�� �˻� - ȸ����, ����, ..)
	 * 	 - 1��
	 * 	 - ������
	 */
	/*
	 * public ArrayList<MemberVo> getMemberList() throws Exception{
	 * ArrayList<AdminVo> adminList = adminDao.readAll(); return adminList; }
	 */
	
	/*
	 * �α׾ƿ�
	 */
	public boolean logout() throws Exception{
		//memberDao.updateLoginStatus(new MemberVO(findLoginMember().getNo(), "", "", "", false, "", 0, 0, 0, 0));
//		FirstPageService.setActiveMember(null);
		return true;
	}
	
	/*
	 * ������ �߰�
	 */
	/*
	 * public boolean addAdmin() throws Exception{
	 * 
	 * 
	 * return; }
	 */
	
	
}
