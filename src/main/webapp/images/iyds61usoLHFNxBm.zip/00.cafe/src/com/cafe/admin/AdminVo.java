package com.cafe.admin;

import java.io.Serializable;

public class AdminVo implements Serializable{
	private String adminId;
	private String passWord;
	private int emNo; //������ȣ
	private int emPass; //��й�ȣ
	private String emName; //�̸�
	private boolean emSe; //����
	private int emNumber; //�ֹι�ȣ
	private int emPhone; //��ȭ��ȣ
	private int emAccount; //���¹�ȣ
	private String emAddress; //�ּ�
	private int emGo; //��ٽð�
	private int emOut; //��ٽð�
	private String emSearch; //�˻�
	

	public AdminVo() {
		
	}
	public AdminVo(int no,String adminName,int phoneNo) {
		this.emNo = no;
		this.emName = adminName;
		this.emPhone = phoneNo;
	}

	
	public String getAdminId() {
		return adminId;
	}
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public int getEmNo() {
		return emNo;
	}
	public void setEmNo(int emNo) {
		this.emNo = emNo;
	}
	public int getEmPass() {
		return emPass;
	}
	public void setEmPass(int emPass) {
		this.emPass = emPass;
	}
	public String getEmName() {
		return emName;
	}
	public void setEmName(String emName) {
		this.emName = emName;
	}
	public boolean isEmSe() {
		return emSe;
	}
	public void setEmSe(boolean emSe) {
		this.emSe = emSe;
	}
	public int getEmNumber() {
		return emNumber;
	}
	public void setEmNumber(int emNumber) {
		this.emNumber = emNumber;
	}
	public int getEmPhone() {
		return emPhone;
	}
	public void setEmPhone(int emPhone) {
		this.emPhone = emPhone;
	}
	public int getEmAccount() {
		return emAccount;
	}
	public void setEmAccount(int emAccount) {
		this.emAccount = emAccount;
	}
	public String getEmAddress() {
		return emAddress;
	}
	public void setEmAddress(String emAddress) {
		this.emAddress = emAddress;
	}
	public int getEmGo() {
		return emGo;
	}
	public void setEmGo(int emGo) {
		this.emGo = emGo;
	}
	public int getEmOut() {
		return emOut;
	}
	public void setEmOut(int emOut) {
		this.emOut = emOut;
	}
	public String getEmSearch() {
		return emSearch;
	}
	public void setEmSearch(String emSearch) {
		this.emSearch = emSearch;
	}




	@Override
	public String toString() {
		return "AdminVo [adminId=" + adminId + ", passWord=" + passWord + ", emNo=" + emNo + ", emPass=" + emPass
				+ ", emName=" + emName + ", emSe=" + emSe + ", emNumber=" + emNumber + ", emPhone=" + emPhone
				+ ", emAccount=" + emAccount + ", emAddress=" + emAddress + ", emGo=" + emGo + ", emOut=" + emOut
				+ ", emSearch=" + emSearch + "]";
	}
	
	
	
	
	
	
	
}
