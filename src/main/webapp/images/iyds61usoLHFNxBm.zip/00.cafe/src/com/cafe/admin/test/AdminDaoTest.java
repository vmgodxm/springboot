package com.cafe.admin.test;

import java.util.ArrayList;

import com.cafe.admin.AdminDao;
import com.cafe.admin.AdminVo;



public class AdminDaoTest {

	public static void main(String[] args) throws Exception{
		AdminDao adminDao = new AdminDao();
		System.out.println("--------------------create---------------------");		
		adminDao.create(new AdminVo(1,"asd", 000));
		System.out.println("--------------------readOne---------------------");
		System.out.println(adminDao.readOne("asd"));
		
		System.out.println("--------------------update---------------------");
		adminDao.update(new AdminVo(1,"qwe", 123));
		
		System.out.println("--------------------readAll---------------------");
		ArrayList<AdminVo> adminMemList = adminDao.readAll();
		System.out.println(adminMemList);
		System.out.println("--------------------delete---------------------");
		adminDao.delete(1);
		System.out.println("--------------------readAll---------------------");
		adminMemList = adminDao.readAll();
		System.out.println(adminMemList);
	}

}
