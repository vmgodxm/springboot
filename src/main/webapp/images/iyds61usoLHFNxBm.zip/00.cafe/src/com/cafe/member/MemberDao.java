package com.cafe.member;


	
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/*
Dao(Data Access Object)
 - ���°�ü���� �����͸� �����ϰ��ִ� ����(���̺�)��
   CRUD(Create, Read, Update, Delete) �۾��� �Ҽ��ִ�
   �����޽�带 �������ִ� Ŭ����

 - AccountService��ü�� ��û(�޽��ȣ��)�� �޾Ƽ� 
   Data Access(File, DB)�� ���õ� �������(CRUD)��
   �����ϴ� ��ü
 */
public class MemberDao implements Serializable{
	private File memberFile;

	public MemberDao() throws Exception {
		init();
	}

	private void init() throws Exception {
		memberFile = new File("member.ser");
		if (!memberFile.exists()) {
			System.out.println("------���ϻ���[member.ser]-----");
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(memberFile));
			oos.writeObject(new ArrayList<MemberVo>());

		} else {
			System.out.println("------��������[member.ser]-----");
		}
	}

	/*
	 * file --> ArrayList<Account>
	 */
	private ArrayList<MemberVo> readFile() throws Exception {
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(memberFile));
		ArrayList<MemberVo> memberList = (ArrayList<MemberVo>) ois.readObject();
		ois.close();
		return memberList;
	}

	/*
	 * ArrayList<Account>--> file
	 */
	private void writeFile(ArrayList<MemberVo> memberList) throws Exception {
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(memberFile));
		oos.writeObject(memberList);
		oos.close();

	}

	/*
	 * CREATE
	 */
	public void create(MemberVo membervo) throws Exception {
		ArrayList<MemberVo> memberList = readFile();
		memberList.add(membervo);
		this.writeFile(memberList);
	}

	/*
	 * READ ALL
	 */
	public ArrayList<MemberVo> readAll() throws Exception {
		ArrayList<MemberVo> memberList = readFile();
		return memberList;
	}

	/*
	 * READ ONE
	 */
	public MemberVo readOne(String no) throws Exception {
		MemberVo returnMember = null;
		ArrayList<MemberVo> memberList = readFile();
		for (MemberVo membervo : memberList) {
			if (membervo.getMemNo().equals(no)) {
				returnMember = membervo;
				break;
			}
		}
		return returnMember;
	}
	/*
	 * UPDATE
	 */

	public void update(MemberVo updateMember) throws Exception {
		ArrayList<MemberVo> memberList = readFile();
		for (int i = 0; i < memberList.size(); i++) {
			MemberVo tempMember = memberList.get(i);
			if (tempMember.getMemNo() == updateMember.getMemNo()) {
				memberList.set(i, updateMember);
				break;
			}
		}
		writeFile(memberList);
	}

	/*
	 * DELETE
	 */
	public void delete(String no) throws Exception {
		ArrayList<MemberVo> memberList = readFile();
		for (int i = 0; i < memberList.size(); i++) {
			MemberVo tempMember = memberList.get(i);
			if (tempMember.getMemNo().equals(no)) {
				memberList.remove(i);
				break;
			}
		}
		writeFile(memberList);

	}

}
