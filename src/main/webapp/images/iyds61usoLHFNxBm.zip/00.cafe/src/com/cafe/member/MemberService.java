package com.cafe.member;

public class MemberService {

}
