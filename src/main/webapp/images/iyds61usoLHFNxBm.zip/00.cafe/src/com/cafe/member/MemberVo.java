package com.cafe.member;

import java.io.Serializable;

public class MemberVo implements Serializable{
	private String memName; //�̸�
	private int	memBirth;	//�������
	private int memPhone;	//��ȭ��ȣ
	private String memRemark;	//���
	private int memPo; 	//����Ʈ
	private String memNo; //ȸ����ȣ
	private int memCnt; //����ī��Ʈ
	public MemberVo() {
		
	}
	public MemberVo(String memNo, String memName, int memBirth) {
		this.memNo = memNo;
		this.memName = memName;
		this.memBirth = memBirth;
	}
	public String getMemName() {
		return memName;
	}
	public void setMemName(String memName) {
		this.memName = memName;
	}
	public int getMemBirth() {
		return memBirth;
	}
	public void setMemBirth(int memBirth) {
		this.memBirth = memBirth;
	}
	public int getMemPhone() {
		return memPhone;
	}
	public void setMemPhone(int memPhone) {
		this.memPhone = memPhone;
	}
	public String getMemRemark() {
		return memRemark;
	}
	public void setMemRemark(String memRemark) {
		this.memRemark = memRemark;
	}
	public int getMemPo() {
		return memPo;
	}
	public void setMemPo(int memPo) {
		this.memPo = memPo;
	}
	public String getMemNo() {
		return memNo;
	}
	public void setMemNo(String memNo) {
		this.memNo = memNo;
	}
	public int getMemCnt() {
		return memCnt;
	}
	public void setMemCnt(int memCnt) {
		this.memCnt = memCnt;
	}
	@Override
	public String toString() {
		return "MemberVo [memName=" + memName + ", memBirth=" + memBirth + ", memPhone=" + memPhone + ", memRemark="
				+ memRemark + ", memPo=" + memPo + ", memNo=" + memNo + ", memCnt=" + memCnt + "]";
	}
	
}
