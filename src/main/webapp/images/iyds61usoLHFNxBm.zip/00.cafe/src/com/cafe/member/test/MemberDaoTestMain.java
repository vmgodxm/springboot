package com.cafe.member.test;



import java.io.Serializable;
import java.util.ArrayList;

import com.cafe.member.MemberDao;
import com.cafe.member.MemberVo;

public class MemberDaoTestMain implements Serializable{

	public static void main(String[] args) throws Exception{
		MemberDao memberDao = new MemberDao();
		System.out.println("-------------creat--------------");
		memberDao.create(new MemberVo("1", "��", 20190620));
		System.out.println("-------------readOne--------------");
		System.out.println(memberDao.readOne("1"));
		System.out.println("-------------update-------------");
		memberDao.update(new MemberVo("2", "��", 20190619));
		System.out.println("-------------readAll--------------");
		ArrayList<MemberVo> memberList = memberDao.readAll();
		System.out.println(memberList);
		System.out.println("-------------delete--------------");
		memberDao.delete("1");
		System.out.println("-------------readAll--------------");
		memberList = memberDao.readAll();
		System.out.println(memberList);
	}

}
