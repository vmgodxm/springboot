package com.cafe.order;

import java.io.Serializable;

public class OrderVo implements Serializable{
	private String orderMenu; // �ֹ��޴�
	private String orderList; // �ֹ� ����Ʈ
	private int orderTmpPaY; // ����ݾ�
	private int SearchMem; // ȸ���˻�
	private String orderOption; // �ɼ� üũ�ڽ�
	private String memRemark; // ���
	private String orderListChk; // �ֹ��޴� ��

//		public static final int Americano = 1;
//		public static final int Caramelmacchiato = 2;
//		public static final int Cappucchino = 3;
//		public static final int Espresso = 4;
//		public static final int Cafelatte = 5;
//		public static final int Cafemocca = 6;
//		public static final int Greentea = 7;
//		public static final int Blacktea = 8;
//		public static final int Lemontea = 9;
//		public static final int BananaJuice = 10;
//		public static final int KiwiJuice = 11;
//		public static final int OrangeJuice = 12;
//		public static final int Cheesecake = 13;
//		public static final int Tiramisucake = 14;
//			
//		public static final int Ice = 50;
//		
//		public static final int Rsize = 100;
//		public static final int Lsize = 101;

	private int menuNo;
	private String menuName;
	private String menuKorName;
	private int menuPrice;
	private int menuSize;
	private int menuIce;

	public OrderVo() {

	}
	
	public OrderVo(String orderMenu, String orderList, int orderTmpPaY, int searchMem, String orderOption,
			String memRemark, String orderListChk, int menuNo, String menuName, String menuKorName, int menuPrice,
			int menuSize, int menuIce) {
		super();
		this.orderMenu = orderMenu;
		this.orderList = orderList;
		this.orderTmpPaY = orderTmpPaY;
		this.SearchMem = searchMem;
		this.orderOption = orderOption;
		this.memRemark = memRemark;
		this.orderListChk = orderListChk;
		this.menuNo = menuNo;
		this.menuName = menuName;
		this.menuKorName = menuKorName;
		this.menuPrice = menuPrice;
		this.menuSize = menuSize;
		this.menuIce = menuIce;
	}

	public String getOrderMenu() {
		return orderMenu;
	}

	public void setOrderMenu(String orderMenu) {
		this.orderMenu = orderMenu;
	}

	public String getOrderList() {
		return orderList;
	}

	public void setOrderList(String orderList) {
		this.orderList = orderList;
	}

	public int getOrderTmpPaY() {
		return orderTmpPaY;
	}

	public void setOrderTmpPaY(int orderTmpPaY) {
		this.orderTmpPaY = orderTmpPaY;
	}

	public int getSearchMem() {
		return SearchMem;
	}

	public void setSearchMem(int searchMem) {
		SearchMem = searchMem;
	}

	public String getOrderOption() {
		return orderOption;
	}

	public void setOrderOption(String orderOption) {
		this.orderOption = orderOption;
	}

	public String getMemRemark() {
		return memRemark;
	}

	public void setMemRemark(String memRemark) {
		this.memRemark = memRemark;
	}

	public String getOrderListChk() {
		return orderListChk;
	}

	public void setOrderListChk(String orderListChk) {
		this.orderListChk = orderListChk;
	}

	public int getMenuNo() {
		return menuNo;
	}

	public void setMenuNo(int menuNo) {
		this.menuNo = menuNo;
	}

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public String getMenuKorName() {
		return menuKorName;
	}

	public void setMenuKorName(String menuKorName) {
		this.menuKorName = menuKorName;
	}

	public int getMenuPrice() {
		return menuPrice;
	}

	public void setMenuPrice(int menuPrice) {
		this.menuPrice = menuPrice;
	}

	public int getMenuSize() {
		return menuSize;
	}

	public void setMenuSize(int menuSize) {
		this.menuSize = menuSize;
	}

	public int getMenuIce() {
		return menuIce;
	}

	public void setMenuIce(int menuIce) {
		this.menuIce = menuIce;
	}

//		public Menu(int menuNo) {
//			this.menuNo = menuNo;
//			switch (menuNo) {
//			case Americano:
//				menuName = "Americano";			
//				break;
//			case Caramelmacchiato:
//				menuName = "Caramelmacchiato";			
//				break;
//			case Cappucchino:
//				menuName = "Cappucchino";			
//				break;
//			case Espresso:
//				menuName = "Espresso";			
//				break;
//			case Cafelatte:
//				menuName = "Cafelatte";			
//				break;
//			case Cafemocca:
//				menuName = "Cafemocca";			
//				break;
//			case Greentea:
//				menuName = "Greentea";			
//				break;
//			case Blacktea:
//				menuName = "Blacktea";			
//				break;
//			case Lemontea:
//				menuName = "Lemontea";			
//				break;
//			case BananaJuice:
//				menuName = "BananaJuice";			
//				break;
//			case KiwiJuice:
//				menuName = "KiwiJuice";			
//				break;
//			case OrangeJuice:
//				menuName = "OrangeJuice";			
//				break;
//			}
//		}		

}
