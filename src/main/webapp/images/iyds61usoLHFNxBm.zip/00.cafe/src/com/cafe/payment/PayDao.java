package com.cafe.payment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
/*
Dao(Data Access Object)
 - ���°�ü���� �����͸� �����ϰ��ִ� ����(���̺�)��
   CRUD(Create, Read, Update, Delete) �۾��� �Ҽ��ִ�
   �����޽�带 �������ִ� Ŭ����

 - AccountService��ü�� ��û(�޽��ȣ��)�� �޾Ƽ� 
   Data Access(File, DB)�� ���õ� �������(CRUD)��
   �����ϴ� ��ü
 */
public class PayDao {
	private File payFile;
	
	public PayDao() throws Exception{
		init();
	}
	private void init() throws Exception{
		payFile=new File("PayVo.ser");
		if(!payFile.exists()) {
			System.out.println("------���ϻ���[PayVo.ser]-----");
			ObjectOutputStream oos=
					new ObjectOutputStream(
							new FileOutputStream(payFile));
			oos.writeObject(new ArrayList<PayVo>());
			
		}else {
			System.out.println("------��������[PayVo.ser]-----");
		}
	}
	/*
	 * file --> ArrayList<Account>
	 */
	private ArrayList<PayVo> readFile()throws Exception{
		ObjectInputStream ois=
				new ObjectInputStream(
						new FileInputStream(payFile));
		ArrayList<PayVo> payList = 
				(ArrayList<PayVo>)ois.readObject();
		ois.close();
		return payList;
	}
	/*
	 * ArrayList<Account>--> file 
	 */
	private void writeFile(ArrayList<PayVo> payList) throws Exception{
		ObjectOutputStream oos=
				new ObjectOutputStream(
						new FileOutputStream(payFile));
		oos.writeObject(payList);
		oos.close();
		
	}
	
	/*
	 * CREATE
	 */
	public void create(PayVo payVo) throws Exception{
		ArrayList<PayVo> payList=readFile();
		payList.add(payVo);
		this.writeFile(payList);
	}
	/*
	 * READ ALL
	 */
	public ArrayList<PayVo> readAll() throws Exception{
		ArrayList<PayVo> payList = readFile();
		return payList;
	}
	/*
	 * READ ONE
	 */
	/*
	public PayVo readOne(int cnt) throws Exception{
		PayVo returnPay=null;
		ArrayList<PayVo> payList=readFile();
		for (PayVo pay : payList) {
			if(pay.getCnt()==cnt) {
				returnPay=pay;
				break;
			}
		}
		return returnPay;
	}
	*/
	/*
	 * UPDATE
	 */
	
	public void update(PayVo updatePay) throws Exception{
		ArrayList<PayVo> payList = readFile();
		for (int i = 0; i < payList.size(); i++) {
			PayVo tempPay=payList.get(i);
			if(tempPay.getCnt()==updatePay.getCnt()) {
				payList.set(i, updatePay);
				break;
			}
			
		}
		writeFile(payList);
	}
	/*
	 * DELETE
	 */
	public void delete(int cnt) throws Exception{
		ArrayList<PayVo> payList=readFile();
		for(int i=0;i<payList.size();i++) {
			PayVo tempPay = payList.get(i);
			if(tempPay.getCnt()==cnt) {
				payList.remove(i);
				break;
			}
		}
		writeFile(payList);
		
	}
	
	
	
	
	
	
	
	
	
}
