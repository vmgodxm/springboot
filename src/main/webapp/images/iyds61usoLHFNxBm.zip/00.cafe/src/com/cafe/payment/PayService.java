package com.cafe.payment;

public class PayService {

}
