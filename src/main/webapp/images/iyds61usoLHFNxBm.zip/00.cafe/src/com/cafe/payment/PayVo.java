package com.cafe.payment;

import java.io.Serializable;

public class PayVo implements Serializable{
	private String orderList; //�ֹ����
	private int cnt; //����ī��Ʈ
	private int money; //�ݾ�
	private int totMoney; //�ѱݾ�
	
	public PayVo() {
		// TODO Auto-generated constructor stub
	}
	
	
	public PayVo(String orderList, int cnt, int money, int totMoney) {
		super();
		this.orderList = orderList;
		this.cnt = cnt;
		this.money = money;
		this.totMoney = totMoney;
	}


	public String getOrderList() {
		return orderList;
	}
	public void setOrderList(String orderList) {
		this.orderList = orderList;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public int getTotMoney() {
		return totMoney;
	}
	public void setTotMoney(int totMoney) {
		this.totMoney = totMoney;
	}

	@Override
	public String toString() {
		return "PayVo [orderList=" + orderList + ", cnt=" + cnt + ", money=" + money + ", totMoney=" + totMoney + "]\n";
	}
	
	
}
