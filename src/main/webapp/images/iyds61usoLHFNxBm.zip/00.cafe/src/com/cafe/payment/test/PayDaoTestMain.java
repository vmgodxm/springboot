package com.cafe.payment.test;

import java.util.ArrayList;

import com.cafe.payment.PayDao;
import com.cafe.payment.PayVo;


public class PayDaoTestMain {

	public static void main(String[] args) throws Exception{
		PayDao payDao = new PayDao();
		System.out.println("-----------create---------------");
	
		payDao.create(new PayVo("fff", 3, 200, 5));
		payDao.create(new PayVo("gggg", 8, 889, 3));
		payDao.create(new PayVo("dd", 1, 2, 3));
		System.out.println("----------update-------------");
		payDao.update(new PayVo("dd", 2, 2, 3));
		System.out.println("----------readAll-------------");
		ArrayList<PayVo> payList = payDao.readAll();
		System.out.println(payList);
		System.out.println("----------delete-------------");
		payDao.delete(3);
		System.out.println("----------readAll-------------");
		payList = payDao.readAll();
		System.out.println(payList);
	}

}
