package com.cafe.stock;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
/*
Dao(Data Access Object)
 - ���°�ü���� �����͸� �����ϰ��ִ� ����(���̺�)��
   CRUD(Create, Read, Update, Delete) �۾��� �Ҽ��ִ�
   �����޽�带 �������ִ� Ŭ����

 - AccountService��ü�� ��û(�޽��ȣ��)�� �޾Ƽ� 
   Data Access(File, DB)�� ���õ� �������(CRUD)��
   �����ϴ� ��ü
 */
public class StockDao {
	private File StockFile;
	
	public StockDao() throws Exception{
		init();
	}
	private void init() throws Exception{
		StockFile=new File("Stock.ser");
		if(!StockFile.exists()) {
			System.out.println("------���ϻ���[Stock.ser]-----");
			ObjectOutputStream oos=
					new ObjectOutputStream(
							new FileOutputStream(StockFile));
			oos.writeObject(new ArrayList<StockVo>());
			
		}else {
			System.out.println("------��������[Stock.ser]-----");
		}
	}
	/*
	 * file --> ArrayList<StockVo>
	 */
	private ArrayList<StockVo> readFile()throws Exception{
		ObjectInputStream ois=
				new ObjectInputStream(
						new FileInputStream(StockFile));
		ArrayList<StockVo> stockList = 
				(ArrayList<StockVo>)ois.readObject();
		ois.close();
		return stockList;
	}
	/*
	 * ArrayList<Account>--> file 
	 */
	private void writeFile(ArrayList<StockVo> stockList) throws Exception{
		ObjectOutputStream oos=
				new ObjectOutputStream(
						new FileOutputStream(StockFile));
		oos.writeObject(stockList);
		oos.close();
		
	}
	
	/*
	 * CREATE
	 */
	public void create(StockVo stock) throws Exception{
		ArrayList<StockVo> stockList=readFile();
		stockList.add(stock);
		this.writeFile(stockList);
	}
	/*
	 * READ ALL
	 */
	public  ArrayList<StockVo> readAll() throws Exception{
		ArrayList<StockVo> stockList = readFile();
		return stockList;
	}
	/*
	 * READ ONE
	 */
	public StockVo readOne(String stockName) throws Exception{
		StockVo returnstock=null;
		ArrayList<StockVo> stockList=readFile();
		for (StockVo stock : stockList) {
			if(stock.getItemName().equals(stockName)) {
				returnstock = stock;
				break;
			}
		}
		return returnstock;
	}
	
	/*
	 * UPDATE
	 */
	
	public void update(StockVo updateStockVo) throws Exception {
		ArrayList<StockVo> stockList = readFile();
		
		for (int i = 0; i < stockList.size(); i++) {
			StockVo tempStockVo = stockList.get(i);
			if(tempStockVo.getItemName().equals(updateStockVo.getItemName())) {
				stockList.set(i, updateStockVo);
				break;
			}
		}
		
		writeFile(stockList);
		
	}
	
	/*
	 * Delete
	 */
	public void delete(String stockName) throws Exception {
		ArrayList<StockVo> stockList = readFile();
		
		for (int i = 0; i < stockList.size(); i++) {
			StockVo tempStockVo = stockList.get(i);
			if(tempStockVo.getItemName().equals(stockName)) {
				stockList.remove(i);
				break;
			}
		}
		writeFile(stockList);
	}
	
	
	
	
	
	
	
	
	
}

