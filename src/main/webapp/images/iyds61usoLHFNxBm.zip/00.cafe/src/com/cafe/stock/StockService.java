package com.cafe.stock;

public class StockService {

}
