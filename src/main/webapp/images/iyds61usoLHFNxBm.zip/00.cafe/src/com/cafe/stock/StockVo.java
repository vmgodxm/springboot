package com.cafe.stock;

import java.io.Serializable;

public class StockVo implements Serializable{
	private String search; //�˻���
	private String itemName; //�̸�
	private int itemDate; //�������
	private int itemCnt; //����
	private int itemPrice; //����
	private String itemCom; //�ŷ�ó
	
	public StockVo() {
		// TODO Auto-generated constructor stub
	}

	public StockVo(String search, String itemName, int itemCnt) {
		this.search = search;
		this.itemName = itemName;
		this.itemCnt = itemCnt;
		
	}
	
	@Override
	public String toString() {
		return "StockVo [search=" + search + ", itemName=" + itemName + ", itemDate=" + itemDate + ", itemCnt="
				+ itemCnt + ", itemPrice=" + itemPrice + ", itemCom=" + itemCom + "]";
	}


	public String getSearch() {
		return search;
	}


	public void setSearch(String search) {
		this.search = search;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public int getItemDate() {
		return itemDate;
	}


	public void setItemDate(int itemDate) {
		this.itemDate = itemDate;
	}


	public int getItemCnt() {
		return itemCnt;
	}


	public void setItemCnt(int itemCnt) {
		this.itemCnt = itemCnt;
	}


	public int getItemPrice() {
		return itemPrice;
	}


	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}


	public String getItemCom() {
		return itemCom;
	}


	public void setItemCom(String itemCom) {
		this.itemCom = itemCom;
	}
	
	
	
	
	
}