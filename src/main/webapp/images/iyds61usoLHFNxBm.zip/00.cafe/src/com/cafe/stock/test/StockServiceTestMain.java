package com.cafe.stock.test;

import java.util.ArrayList;

import com.cafe.stock.StockDao;
import com.cafe.stock.StockVo;

public class StockServiceTestMain {
	//String search, String itemName, int itemCnt)
	public static void main(String[] args) throws Exception{
		StockDao stockdao = new StockDao();
		stockdao.create(new StockVo("�Ƴ�", "����", 1000));
		stockdao.create(new StockVo("����", "�ƿ�", 2000));
		System.out.println("d");
		stockdao.update(new StockVo("��ġ", "����", 5000));
		stockdao.readOne("�Ƴ�");
		
		System.out.println("====================readall=======");
		ArrayList<StockVo> stocklist = stockdao.readAll();
		System.out.println(stocklist);
		
		System.out.println("==========delete========================");
		stockdao.delete("����");
		System.out.println(stocklist);
//		System.out.println(StockDao.readOne("�Ƴ�"));
//		System.out.println("-------------creat--------------");
//		memberDao.create(new MemberVo("1", "��", 20190620));
//		System.out.println("-------------readOne--------------");
//		System.out.println(memberDao.readOne("1"));
//		System.out.println("-------------update-------------");
//		memberDao.update(new MemberVo("2", "��", 20190619));
//		System.out.println("-------------readAll--------------");
	//	ArrayList<MemberVo> memberList = memberDao.readAll();
//		System.out.println(memberList);
//		System.out.println("-------------delete--------------");
//		memberDao.delete("1");
//		System.out.println("-------------readAll--------------");
//		memberList = memberDao.readAll();
//		System.out.println(memberList);
	
	
	}
	
	
	
	
}
