package com.cafe.ui;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import java.awt.CardLayout;

public class MemberJoinPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public MemberJoinPanel() {
		setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(58, 116, 548, 376);
		add(panel);
		panel.setLayout(null);

	}
}
