package com.cafe.ui;

import javax.swing.JPanel;

public class cafeMainPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public cafeMainPanel() {

	}

}
