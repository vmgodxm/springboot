package com.cafe.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import javax.swing.JList;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class cafePanelTestFrameMain extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					cafePanelTestFrameMain frame = new cafePanelTestFrameMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public cafePanelTestFrameMain() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1037, 765);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel productPanel = new JPanel();
		contentPane.add(productPanel, BorderLayout.CENTER);
		productPanel.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		tabbedPane.setFont(new Font("����", Font.PLAIN, 18));
		tabbedPane.setBounds(0, 0, 1011, 696);
		productPanel.add(tabbedPane);
		
		cafeTabOrder cafeTabOrder_ = new cafeTabOrder();
		tabbedPane.addTab("             �ֹ�", null, cafeTabOrder_, null);
		
		cafeTabPay cafeTabPay_ = new cafeTabPay();
		tabbedPane.addTab("             ���", null, cafeTabPay_, null);
		
		cafeTabMember cafeTabMember_ = new cafeTabMember();
		tabbedPane.addTab("             ȸ������", null, cafeTabMember_, null);
		
		cafeTabEmpl cafeTabEmpl_ = new cafeTabEmpl();
		tabbedPane.addTab("             ��������", null, cafeTabEmpl_, null);
		cafeTabEmpl_.setVisible(false);
		cafeTabEmpl_.setEnabled(false);
		
		cafeTabStock cafeTabStock_ = new cafeTabStock();
		tabbedPane.addTab("             �������", null, cafeTabStock_, null);
		
		//tabbedPane.setEnabledAt(3, false);//4��°�� ��Ȱ��
		tabbedPane.setEnabled(false);
		
		JMenuBar menuBar = new JMenuBar();
		contentPane.add(menuBar, BorderLayout.NORTH);
		
		JMenu login = new JMenu("�α���");
		menuBar.add(login);
		login.setEnabled(false);//�α��ι�ư ��Ȱ��
		JMenu logout = new JMenu("�α׾ƿ�");
		menuBar.add(logout);
	}
}
