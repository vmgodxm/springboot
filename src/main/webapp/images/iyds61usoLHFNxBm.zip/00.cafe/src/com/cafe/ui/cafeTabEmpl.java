package com.cafe.ui;

import javax.swing.JPanel;
import java.awt.Color;

public class cafeTabEmpl extends JPanel {

	/**
	 * Create the panel.
	 */
	public cafeTabEmpl() {
		setBackground(new Color(255, 20, 147));

	}

}
