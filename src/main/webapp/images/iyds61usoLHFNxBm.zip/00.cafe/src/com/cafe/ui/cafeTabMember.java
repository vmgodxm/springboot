package com.cafe.ui;

import javax.swing.JPanel;
import java.awt.Color;

public class cafeTabMember extends JPanel {

	/**
	 * Create the panel.
	 */
	public cafeTabMember() {
		setBackground(new Color(255, 99, 71));
		setForeground(new Color(0, 0, 0));

	}

}
