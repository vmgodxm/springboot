package com.cafe.ui;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.CardLayout;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JToggleButton;
import javax.swing.ImageIcon;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class cafeTabOrder extends JPanel {
	private JTextField sum;
	private JTextField textField;
	private JPanel cardMenu;

	/**
	 * Create the panel.
	 */
	public cafeTabOrder() {
		setBackground(new Color(169, 169, 169));
		setLayout(null);
		
		JPanel cardMenu = new JPanel();
		cardMenu.setBounds(35, 111, 686, 455);
		add(cardMenu);
		cardMenu.setLayout(new CardLayout(0, 0));
		
		cardChildPanelMenu cardChildPanelMenu_ = new cardChildPanelMenu();
		cardMenu.add(cardChildPanelMenu_, "menu");
		
		JButton btnNewButton = new JButton("\uCDE8\uC18C");
		btnNewButton.setBounds(203, 372, 115, 47);
		cardChildPanelMenu_.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uC635\uC158\uC120\uD0DD");
		btnNewButton_1.setBounds(371, 372, 115, 47);
		cardChildPanelMenu_.add(btnNewButton_1);
		
		JToggleButton tglbtnNewToggleButton = new JToggleButton("New toggle button");
		tglbtnNewToggleButton.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				System.out.println(e.getStateChange());
			}
		});
		tglbtnNewToggleButton.setSelectedIcon(new ImageIcon("C:\\JAVA_BIGDATA\\workspaceSE\\99.image\\ball.jpg"));
		tglbtnNewToggleButton.setIcon(new ImageIcon("C:\\JAVA_BIGDATA\\workspaceSE\\99.image\\ball.png"));
		tglbtnNewToggleButton.setForeground(new Color(255, 20, 147));
		tglbtnNewToggleButton.setBounds(36, 51, 131, 139);
		cardChildPanelMenu_.add(tglbtnNewToggleButton);
		
		JToggleButton tglbtnNewToggleButton_1 = new JToggleButton("New toggle button");
		tglbtnNewToggleButton_1.setBounds(188, 54, 130, 133);
		cardChildPanelMenu_.add(tglbtnNewToggleButton_1);
		
		JToggleButton tglbtnNewToggleButton_2 = new JToggleButton("New toggle button");
		tglbtnNewToggleButton_2.setBounds(344, 54, 131, 133);
		cardChildPanelMenu_.add(tglbtnNewToggleButton_2);
		
		JToggleButton toggleButton = new JToggleButton("New toggle button");
		toggleButton.setBounds(497, 54, 130, 133);
		cardChildPanelMenu_.add(toggleButton);
		
		JToggleButton toggleButton_1 = new JToggleButton("New toggle button");
		toggleButton_1.setBounds(36, 213, 130, 133);
		cardChildPanelMenu_.add(toggleButton_1);
		
		JToggleButton toggleButton_2 = new JToggleButton("New toggle button");
		toggleButton_2.setBounds(188, 213, 130, 133);
		cardChildPanelMenu_.add(toggleButton_2);
		
		JToggleButton toggleButton_3 = new JToggleButton("New toggle button");
		toggleButton_3.setBounds(344, 213, 131, 133);
		cardChildPanelMenu_.add(toggleButton_3);
		
		JToggleButton toggleButton_4 = new JToggleButton("New toggle button");
		toggleButton_4.setBounds(497, 213, 130, 133);
		cardChildPanelMenu_.add(toggleButton_4);
		
		cardChildPanelOption cardChildPanelOption_ = new cardChildPanelOption();
		cardMenu.add(cardChildPanelOption_, "option");
		
		cardChildPanelcheck cardChildPanelcheck_ = new cardChildPanelcheck();
		cardMenu.add(cardChildPanelcheck_, "orderCheck");
		
		JPanel listPanel = new JPanel();
		listPanel.setBackground(new Color(30, 144, 255));
		listPanel.setBounds(753, 111, 225, 314);
		add(listPanel);
		listPanel.setLayout(null);
		
		JList tmpList = new JList();
		tmpList.setBounds(12, 10, 201, 243);
		listPanel.add(tmpList);
		
		sum = new JTextField();
		sum.setBounds(12, 263, 201, 41);
		listPanel.add(sum);
		sum.setColumns(10);
		
		JButton menuB = new JButton("�޴�");
		menuB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout cl=(CardLayout)cardMenu.getLayout();
				 cl.show(cardMenu, "menu");
			}
		});
		menuB.setBounds(35, 66, 97, 35);
		add(menuB);
		
		JButton optionB = new JButton("�ɼ�");
		optionB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout cl=(CardLayout)cardMenu.getLayout();
				 cl.show(cardMenu, "option");
			}
		});
		optionB.setBounds(144, 66, 97, 35);
		add(optionB);
		
		JButton checkB = new JButton("�ֹ�Ȯ��");
		checkB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout cl=(CardLayout)cardMenu.getLayout();
				 cl.show(cardMenu, "orderCheck");
			}
		});
		checkB.setBounds(253, 66, 97, 35);
		add(checkB);
		
		textField = new JTextField();
		textField.setBounds(753, 519, 158, 47);
		add(textField);
		textField.setColumns(10);
		
		JButton serchMem = new JButton("\uAC80\uC0C9");
		serchMem.setBounds(918, 515, 60, 53);
		add(serchMem);
		
		JButton btnNewButton_3 = new JButton("\uD68C\uC6D0\uB4F1\uB85D");
		btnNewButton_3.setBounds(753, 459, 104, 36);
		add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("\uACC4\uC0B0\uAE30");
		btnNewButton_4.setBounds(869, 459, 109, 36);
		add(btnNewButton_4);

	}

	public void changePanel(String panelName) {
		CardLayout cl=(CardLayout)cardMenu.getLayout();
		cl.show(cardMenu, panelName);
	}	
}





