package com.cafe.ui;

import javax.swing.JPanel;
import java.awt.Color;

public class cafeTabPay extends JPanel {

	/**
	 * Create the panel.
	 */
	public cafeTabPay() {
		setBackground(new Color(224, 255, 255));
		setForeground(new Color(0, 0, 0));

	}

}
