package com.cafe.ui;

import javax.swing.JPanel;

public class cafeTabStock extends JPanel {

	/**
	 * Create the panel.
	 */
	public cafeTabStock() {

	}

}
