package com.cafe.ui;

import javax.swing.JPanel;
import java.awt.Color;

public class cardChildPanelMenu extends JPanel {

	/**
	 * Create the panel.
	 */
	public cardChildPanelMenu() {
		setBackground(new Color(30, 144, 255));
		setLayout(null);

	}

}
