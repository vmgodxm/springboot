package com.cafe.ui;

import javax.swing.JPanel;
import java.awt.Color;

public class cardChildPanelOption extends JPanel {

	/**
	 * Create the panel.
	 */
	public cardChildPanelOption() {
		setBackground(new Color(0, 191, 255));
		setLayout(null);

	}

}
