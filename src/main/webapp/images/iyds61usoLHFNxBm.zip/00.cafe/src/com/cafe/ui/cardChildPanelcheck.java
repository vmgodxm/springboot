package com.cafe.ui;

import javax.swing.JPanel;
import java.awt.Color;

public class cardChildPanelcheck extends JPanel {

	/**
	 * Create the panel.
	 */
	public cardChildPanelcheck() {
		setBackground(new Color(135, 206, 235));

	}

}
